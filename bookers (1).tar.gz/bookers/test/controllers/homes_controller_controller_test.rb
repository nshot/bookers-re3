require 'test_helper'

class HomesControllerControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get homes_controller_new_url
    assert_response :success
  end

end

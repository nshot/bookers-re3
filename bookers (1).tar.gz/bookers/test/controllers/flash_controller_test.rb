require 'test_helper'

class FlashControllerTest < ActionDispatch::IntegrationTest
  test "should get create" do
    get flash_create_url
    assert_response :success
  end

  test "should get update" do
    get flash_update_url
    assert_response :success
  end

end

class HomesControllerController < ApplicationController
  def top
  end
end

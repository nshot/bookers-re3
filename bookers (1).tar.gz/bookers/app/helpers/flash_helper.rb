module FlashHelper
end
